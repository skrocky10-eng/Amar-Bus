package com.amarbus.app.data

data class CommunityReport(
    val id: String,
    val direction: String, // "out" or "back"
    val busOriginTime: String,
    val stopName: String,
    val reportedArrivalTime: String,
    val commuterName: String? = null,
    val note: String? = null,
    val status: String // "pending", "approved", "rejected"
)

object CommunityRepository {
    private val reports = mutableListOf(
        CommunityReport(
            id = "rep-1",
            direction = "out",
            busOriginTime = "7:10 AM",
            stopName = "Galsi Chowmatha",
            reportedArrivalTime = "7:42 AM",
            commuterName = "Bikram S.",
            note = "Usually reaches Galsi on time",
            status = "approved"
        ),
        CommunityReport(
            id = "rep-2",
            direction = "back",
            busOriginTime = "8:00 AM",
            stopName = "Galsi Chowmatha",
            reportedArrivalTime = "8:42 AM",
            commuterName = "Subhasish",
            note = "Took ~42 mins from Burdwan",
            status = "pending"
        )
    )

    fun getReports(): List<CommunityReport> = reports.toList()

    fun getApprovedReport(direction: String, originTime: String): CommunityReport? {
        return reports.find { it.status == "approved" && it.direction == direction && it.busOriginTime == originTime }
    }

    fun addReport(report: CommunityReport) {
        reports.add(0, report)
    }

    fun approveReport(id: String) {
        val index = reports.indexOfFirst { it.id == id }
        if (index != -1) {
            reports[index] = reports[index].copy(status = "approved")
        }
    }

    fun rejectReport(id: String) {
        val index = reports.indexOfFirst { it.id == id }
        if (index != -1) {
            reports[index] = reports[index].copy(status = "rejected")
        }
    }
}
