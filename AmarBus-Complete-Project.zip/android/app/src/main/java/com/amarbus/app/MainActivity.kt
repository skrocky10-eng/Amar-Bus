package com.amarbus.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import com.amarbus.app.ui.SplashScreen
import com.amarbus.app.ui.TimetableScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var showIntro by remember { mutableStateOf(true) }
                var isBengali by remember { mutableStateOf(false) }

                Crossfade(
                    targetState = showIntro,
                    animationSpec = tween(durationMillis = 400),
                    label = "IntroTransition"
                ) { isIntroVisible ->
                    if (isIntroVisible) {
                        SplashScreen(
                            isBengali = isBengali,
                            onDismiss = { showIntro = false }
                        )
                    } else {
                        TimetableScreen(
                            isBengali = isBengali,
                            onToggleLanguage = { isBengali = !isBengali },
                            onShowIntro = { showIntro = true }
                        )
                    }
                }
            }
        }
    }
}
