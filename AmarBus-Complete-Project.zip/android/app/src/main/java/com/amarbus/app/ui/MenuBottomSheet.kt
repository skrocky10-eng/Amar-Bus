package com.amarbus.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuBottomSheet(
    isBengali: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var activeView by remember { mutableStateOf("menu") }
    var tipAmount by remember { mutableIntStateOf(20) }
    var isCopied by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (activeView) {
                "menu" -> {
                    Text(
                        text = if (isBengali) "আমার বাস মেনু" else "Amar Bus Menu",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF075B43)
                    )

                    // About Card
                    Card(
                        onClick = { activeView = "about" },
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F7F5)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF075B43))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(if (isBengali) "আমার বাস সম্পর্কে" else "About Amar Bus", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Gohogram ↔ Galsi ↔ Burdwan", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            Text("➔", color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Contact Card
                    Card(
                        onClick = { activeView = "contact" },
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F7F5)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Email, contentDescription = null, tint = Color(0xFF0284C7))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(if (isBengali) "যোগাযোগ করুন" else "Contact Us", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("WhatsApp & Email Support", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            Text("➔", color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Feedback Card
                    Card(
                        onClick = { activeView = "feedback" },
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F7F5)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Feedback, contentDescription = null, tint = Color(0xFFD97706))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(if (isBengali) "মতামত ও পরামর্শ" else "Feedback & Suggestions", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(if (isBengali) "নতুন রুটের প্রস্তাব পাঠান" else "Suggest routes or report times", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            Text("➔", color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Tip / Support Card
                    Card(
                        onClick = { activeView = "tip" },
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("☕", fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(if (isBengali) "চায়ের কাপের অনুদান (Tip / Support)" else "Tip a Chai ☕ (Support App)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF78350F))
                                    Text(if (isBengali) "সার্ভার পরিচালনায় সহায়তা করুন" else "Small tip to keep app free & updated", fontSize = 11.sp, color = Color(0xFF92400E))
                                }
                            }
                            Text("➔", color = Color(0xFF78350F), fontWeight = FontWeight.Bold)
                        }
                    }
                }

                "about" -> {
                    TextButton(onClick = { activeView = "menu" }) { Text("← " + if (isBengali) "মেনুতে ফিরুন" else "Back to Menu") }
                    Text(if (isBengali) "আমার বাস সম্পর্কে" else "About Amar Bus", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color(0xFF075B43))
                    Text(
                        text = if (isBengali) "আমার বাস পূর্ব বর্ধমান জেলার গোহগ্রাম, গলসী ও বর্ধমান রুটের গ্রামীণ যাত্রী ও সাধারণ মানুষের সুবিধার্থে তৈরি করা একটি নির্ভরযোগ্য সময়সূচি নির্দেশিকা।"
                               else "Amar Bus is a community-run public transit directory for rural and daily commuters between Gohogram, Galsi, and Burdwan.",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }

                "contact" -> {
                    TextButton(onClick = { activeView = "menu" }) { Text("← " + if (isBengali) "মেনুতে ফিরুন" else "Back to Menu") }
                    Text(if (isBengali) "যোগাযোগ মাধ্যম" else "Contact Information", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color(0xFF075B43))
                    Text("Email: skrocky10@gmail.com", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?text=Hello%20Amar%20Bus"))
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                    ) {
                        Text("Chat on WhatsApp", color = Color.White)
                    }
                }

                "feedback" -> {
                    TextButton(onClick = { activeView = "menu" }) { Text("← " + if (isBengali) "মেনুতে ফিরুন" else "Back to Menu") }
                    Text(if (isBengali) "মতামত বা পরামর্শ পাঠান" else "Feedback & Suggestions", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color(0xFF075B43))
                    Text(
                        text = if (isBengali) "নতুন রুটের প্রস্তাব বা বাসের সময়ের সংশোধনের জন্য skrocky10@gmail.com এ ইমেইল পাঠান।"
                               else "Send your route suggestions or schedule updates directly to skrocky10@gmail.com.",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }

                "tip" -> {
                    TextButton(onClick = { activeView = "menu" }) { Text("← " + if (isBengali) "মেনুতে ফিরুন" else "Back to Menu") }
                    Text(if (isBengali) "চায়ের কাপের অনুদান ☕" else "Support Amar Bus ☕", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color(0xFF92400E))
                    Text(
                        text = if (isBengali) "অ্যাপটি সবার জন্য সম্পূর্ণ ফ্রি। সার্ভার ও নিয়মিত সময়সূচি আপডেট রাখতে সামান্য সহায়তা করতে পারেন।"
                               else "Every contribution helps keep this service running free for all passengers in Purba Bardhaman.",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(10, 20, 50).forEach { amt ->
                            Button(
                                onClick = { tipAmount = amt },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (tipAmount == amt) Color(0xFFD97706) else Color(0xFFFEF3C7)
                                )
                            ) {
                                Text("₹$amt", color = if (tipAmount == amt) Color.White else Color(0xFF78350F))
                            }
                        }
                    }

                    Button(
                        onClick = {
                            clipboardManager.setText(AnnotatedString("amarbus@upi"))
                            isCopied = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF075B43)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isCopied) "UPI Copied (amarbus@upi)!" else "Copy UPI ID: amarbus@upi", color = Color.White)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
