package com.amarbus.app.data

data class StopInfo(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val kmFromGohogram: Int,
    val offsetFromGohogramMins: Int,
    val offsetFromBurdwanMins: Int,
    val isMiddleStop: Boolean = false
)

data class BusEntry(
    val id: String,
    val time: String,
    val tag: String,
    val departureMinutes: Int
)

data class RouteBusItem(
    val id: String,
    val departTime: String,
    val arriveTime: String,
    val durationMins: Int,
    val tag: String,
    val fromStopName: String,
    val departureMinutes: Int,
    val isFirstBus: Boolean = false,
    val isLastBus: Boolean = false
)

object BusRepository {
    val STOPS = listOf(
        StopInfo("gohogram", "Gohogram", "গোহগ্রাম", 0, 0, 70),
        StopInfo("adrahati", "Adrahati", "আদ্রাহাটি", 6, 11, 59),
        StopInfo("goromba", "Goromba", "গড়মবা", 10, 18, 52),
        StopInfo("mollasarul", "Mollasarul", "মোল্লাসড়ুল", 13, 24, 46),
        StopInfo("galsi", "Galsi (Middle Stop)", "গলসী (মধ্যবর্তী স্টপ)", 16, 30, 40, isMiddleStop = true),
        StopInfo("khana", "Khana Junction", "খানা জংশন", 24, 46, 24),
        StopInfo("burdwan", "Burdwan (Nababhat)", "বর্ধমান (নবাবহাট)", 34, 70, 0)
    )

    private val RAW_OUT = listOf(
        "4:35 AM" to "", "5:20 AM" to "", "6:05 AM" to "", "6:20 AM" to "Katwa",
        "6:40 AM" to "Goromba", "7:10 AM" to "Super", "7:30 AM" to "Mollasarul",
        "7:50 AM" to "Super", "8:10 AM" to "", "8:35 AM" to "Super",
        "8:50 AM" to "Super", "9:15 AM" to "Super", "10:10 AM" to "Super",
        "10:30 AM" to "", "11:30 AM" to "", "12:10 PM" to "", "12:25 PM" to "Super",
        "12:50 PM" to "Super", "1:30 PM" to "Mollasarul", "1:40 PM" to "Super",
        "2:10 PM" to "Super", "2:20 PM" to "", "3:10 PM" to "Super", "4:40 PM" to "Super • Last trip"
    )

    private val RAW_BACK = listOf(
        "8:00 AM" to "", "8:20 AM" to "", "9:00 AM" to "Goromba Super", "9:20 AM" to "",
        "9:30 AM" to "Super", "9:50 AM" to "Super", "10:00 AM" to "Mollasarul",
        "10:10 AM" to "Super", "10:35 AM" to "", "10:45 AM" to "", "11:15 AM" to "Super",
        "12:05 PM" to "Super", "12:45 PM" to "Super", "1:40 PM" to "", "2:20 PM" to "",
        "3:10 PM" to "Super", "3:25 PM" to "Super", "4:10 PM" to "Super", "4:50 PM" to "",
        "5:00 PM" to "Mollasarul", "5:20 PM" to "Super", "5:40 PM" to "Super", "6:50 PM" to "Super • Last trip"
    )

    private fun parseMinutes(timeStr: String): Int {
        val parts = timeStr.trim().split(" ")
        val tParts = parts[0].split(":")
        var h = tParts[0].toInt()
        val m = tParts[1].toInt()
        if (parts[1] == "PM" && h < 12) h += 12
        if (parts[1] == "AM" && h == 12) h = 0
        return h * 60 + m
    }

    private fun formatMinutes(totalMins: Int): String {
        val normalized = ((totalMins % 1440) + 1440) % 1440
        var h = normalized / 60
        val m = normalized % 60
        val period = if (h >= 12) "PM" else "AM"
        if (h > 12) h -= 12
        if (h == 0) h = 12
        val minStr = if (m < 10) "0$m" else "$m"
        return "$h:$minStr $period"
    }

    val OUT_TRIPS: List<BusEntry> = RAW_OUT.mapIndexed { i, (t, tag) ->
        BusEntry("out-$i", t, tag, parseMinutes(t))
    }

    val BACK_TRIPS: List<BusEntry> = RAW_BACK.mapIndexed { i, (t, tag) ->
        BusEntry("back-$i", t, tag, parseMinutes(t))
    }

    fun getBuses(fromId: String, toId: String, isBengali: Boolean): List<RouteBusItem> {
        val from = STOPS.find { it.id == fromId } ?: STOPS[0]
        val to = STOPS.find { it.id == toId } ?: STOPS[4]
        val isOut = from.kmFromGohogram < to.kmFromGohogram
        val baseList = if (isOut) OUT_TRIPS else BACK_TRIPS

        val result = baseList.map { trip ->
            val depMins = if (isOut) trip.departureMinutes + from.offsetFromGohogramMins
                          else trip.departureMinutes + from.offsetFromBurdwanMins
            val arrMins = if (isOut) trip.departureMinutes + to.offsetFromGohogramMins
                          else trip.departureMinutes + to.offsetFromBurdwanMins

            RouteBusItem(
                id = "${trip.id}-$fromId-$toId",
                departTime = formatMinutes(depMins),
                arriveTime = formatMinutes(arrMins),
                durationMins = kotlin.math.max(10, arrMins - depMins),
                tag = trip.tag,
                fromStopName = if (isBengali) from.nameBn else from.nameEn,
                departureMinutes = depMins
            )
        }

        return result.mapIndexed { idx, item ->
            item.copy(
                isFirstBus = idx == 0,
                isLastBus = idx == result.size - 1
            )
        }
    }
}
