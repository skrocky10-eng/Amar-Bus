package com.amarbus.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amarbus.app.data.BusRepository
import com.amarbus.app.data.RouteBusItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimetableScreen(
    isBengali: Boolean,
    onToggleLanguage: () -> Unit,
    onShowIntro: () -> Unit
) {
    val context = LocalContext.current
    var fromStopId by remember { mutableStateOf("gohogram") }
    var toStopId by remember { mutableStateOf("galsi") }
    var filterTag by remember { mutableStateOf("all") }
    var searchQuery by remember { mutableStateOf("") }

    val buses = remember(fromStopId, toStopId, isBengali) {
        BusRepository.getBuses(fromStopId, toStopId, isBengali)
    }

    val filtered = remember(buses, filterTag, searchQuery) {
        buses.filter { bus ->
            val matchesTag = filterTag == "all" || bus.tag.contains(filterTag, ignoreCase = true)
            val matchesQuery = searchQuery.isBlank() ||
                bus.departTime.contains(searchQuery, ignoreCase = true) ||
                bus.arriveTime.contains(searchQuery, ignoreCase = true) ||
                bus.tag.contains(searchQuery, ignoreCase = true)
            matchesTag && matchesQuery
        }
    }

    val fromStopObj = BusRepository.STOPS.find { it.id == fromStopId } ?: BusRepository.STOPS[0]
    val toStopObj = BusRepository.STOPS.find { it.id == toStopId } ?: BusRepository.STOPS[4]

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFF087F5B), Color(0xFF075B43))
                        )
                    )
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isBengali) "বাসের দৈনিক সময়সূচি" else "Live Bus Schedule",
                        color = Color(0xFFD1FAE5),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = onShowIntro,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(20.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(if (isBengali) "ইন্ট্রো" else "Intro", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onToggleLanguage,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(20.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(if (isBengali) "English" else "বাংলা", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isBengali) "🚌 আমার বাস" else "🚌 Amar Bus",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = if (isBengali) "লোকাল বাসের সময়সূচি • গোহগ্রাম ↔ গলসী ↔ বর্ধমান"
                           else "Local bus timetable • Gohogram ↔ Galsi ↔ Burdwan",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp
                )
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF3F7F5))
                .padding(padding)
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Route Selection Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (isBengali) "বাস রুট নির্বাচন করুন" else "SELECT BUS ROUTE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64756D)
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF3F7F5), RoundedCornerShape(14.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(if (isBengali) "কোথা থেকে" else "FROM", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                val fromName = if (isBengali) fromStopObj.nameBn else fromStopObj.nameEn
                                Text(fromName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF13231D))
                            }

                            IconButton(
                                onClick = {
                                    val temp = fromStopId
                                    fromStopId = toStopId
                                    toStopId = temp
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color.White, RoundedCornerShape(10.dp))
                                    .border(1.dp, Color(0xFFE0E9E4), RoundedCornerShape(10.dp))
                            ) {
                                Icon(Icons.Default.SwapHoriz, contentDescription = "Swap", tint = Color(0xFF075B43))
                            }

                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text(if (isBengali) "কোথায় যাবেন" else "TO", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                val toName = if (isBengali) toStopObj.nameBn else toStopObj.nameEn
                                Text(toName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF13231D))
                            }
                        }

                        // Quick Route Preset Buttons
                        Text(
                            text = if (isBengali) "জনপ্রিয় রুটসমূহ:" else "Popular Routes:",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64756D)
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            QuickRouteButton(
                                text = if (isBengali) "গলসী ➔ গোহগ্রাম" else "Galsi ➔ Gohogram",
                                isSelected = fromStopId == "galsi" && toStopId == "gohogram",
                                modifier = Modifier.weight(1f)
                            ) {
                                fromStopId = "galsi"; toStopId = "gohogram"
                            }
                            QuickRouteButton(
                                text = if (isBengali) "গোহগ্রাম ➔ গলসী" else "Gohogram ➔ Galsi",
                                isSelected = fromStopId == "gohogram" && toStopId == "galsi",
                                modifier = Modifier.weight(1f)
                            ) {
                                fromStopId = "gohogram"; toStopId = "galsi"
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            QuickRouteButton(
                                text = if (isBengali) "গোহগ্রাম ➔ বর্ধমান" else "Gohogram ➔ Burdwan",
                                isSelected = fromStopId == "gohogram" && toStopId == "burdwan",
                                modifier = Modifier.weight(1f)
                            ) {
                                fromStopId = "gohogram"; toStopId = "burdwan"
                            }
                            QuickRouteButton(
                                text = if (isBengali) "বর্ধমান ➔ গোহগ্রাম" else "Burdwan ➔ Gohogram",
                                isSelected = fromStopId == "burdwan" && toStopId == "gohogram",
                                modifier = Modifier.weight(1f)
                            ) {
                                fromStopId = "burdwan"; toStopId = "gohogram"
                            }
                        }
                    }
                }
            }

            // Timing Advisory Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFFFDE68A), Color(0xFFFDE68A))))
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (isBengali) "জরুরি বিজ্ঞপ্তি:" else "Timing Advisory:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF92400E)
                            )
                            Text(
                                text = if (isBengali) "বাসের সময় সম্পূর্ণ নির্ভুল নাও হতে পারে। রাস্তার ট্রাফিকের কারণে বাস কয়েক মিনিট আগে বা দেরিতে পৌঁছাতে পারে। ৫-১০ মিনিট আগে স্টপে উপস্থিত থাকুন।"
                                       else "Bus times may not be 100% accurate. Buses can be delayed or arrive a few minutes fast (early) due to traffic. Please reach your stop 5-10 minutes early.",
                                fontSize = 11.sp,
                                color = Color(0xFFB45309),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            // Timetable Header Count
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val fromName = if (isBengali) fromStopObj.nameBn else fromStopObj.nameEn
                    val toName = if (isBengali) toStopObj.nameBn else toStopObj.nameEn
                    Text(
                        text = "$fromName ➔ $toName",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = Color(0xFF13231D)
                    )
                    Text(
                        text = "${filtered.size} ${if (isBengali) "টি বাস" else "Buses"}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        color = Color(0xFF075B43)
                    )
                }
            }

            // Bus items
            items(filtered) { bus ->
                BusCardItem(bus = bus, isBengali = isBengali)
            }

            // Footer WhatsApp Share & Disclaimer
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                data = Uri.parse("https://api.whatsapp.com/send?text=Check out Amar Bus app for local bus schedules between Gohogram, Galsi, and Burdwan!")
                            }
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (isBengali) "অ্যাপটি হোয়াটসঅ্যাপে শেয়ার করুন" else "Share App on WhatsApp", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Amar Bus • Informational timetable only • No booking",
                        color = Color(0xFF64756D),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun QuickRouteButton(text: String, isSelected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) Color(0xFF087F5B) else Color(0xFFF3F7F5)
        ),
        shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = if (isSelected) Color.White else Color(0xFF075B43),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun BusCardItem(bus: RouteBusItem, isBengali: Boolean) {
    val bgColor = when {
        bus.isFirstBus -> Color(0xFFF0F9FF)
        bus.isLastBus -> Color(0xFFFEF3C7)
        else -> Color.White
    }

    val borderColor = when {
        bus.isFirstBus -> Color(0xFF38BDF8)
        bus.isLastBus -> Color(0xFFF59E0B)
        else -> Color(0xFFE0E9E4)
    }

    val timeColor = when {
        bus.isFirstBus -> Color(0xFF0369A1)
        bus.isLastBus -> Color(0xFF78350F)
        else -> Color(0xFF075B43)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = bus.departTime,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = timeColor
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "➔ ${bus.arriveTime}",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "~${bus.durationMins} mins • ${bus.fromStopName}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                if (bus.isFirstBus) {
                    Surface(
                        color = Color(0xFFE0F2FE),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7DD3FC))
                    ) {
                        Text(
                            text = if (isBengali) "🌅 প্রথম বাস" else "🌅 First Bus",
                            color = Color(0xFF0369A1),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                } else if (bus.isLastBus) {
                    Surface(
                        color = Color(0xFFFDE68A),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B))
                    ) {
                        Text(
                            text = if (isBengali) "🌙 শেষ বাস" else "🌙 Last Bus",
                            color = Color(0xFF78350F),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                } else if (bus.tag.isNotEmpty()) {
                    Surface(
                        color = Color(0xFFE7F5EE),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0))
                    ) {
                        Text(
                            text = bus.tag,
                            color = Color(0xFF076443),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                } else {
                    Surface(
                        color = Color(0xFFF3F4F6),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isBengali) "লোকাল বাস" else "Local bus",
                            color = Color.Gray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
